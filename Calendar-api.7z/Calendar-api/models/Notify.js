const mongoose = require('mongoose');

const notifySchema = new mongoose.Schema({
  user:{
    type: mongoose.Schema.ObjectId,
    ref: 'user',
  },
  message: {
    type: String,
    trim: true,
  },
  status:{
    type:String,
    enum:['seen','unseen'],
    default:'unseen'
  },
  createdAt:{
    type:Date,
    default:Date.now
  }
  
});


const Notify=mongoose.model('Notify',notifySchema)
module.exports=Notify