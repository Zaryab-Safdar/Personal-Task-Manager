const mongoose = require('mongoose');
const validator = require('validator');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

// TODO: Database validation
const userSchema = new mongoose.Schema({
  // name validation
  name: {
    type: String,
    required: [true, 'Please tell us your name!'],
    unique: true,
    trim: true,
    maxlength: [20, 'must be less than or equal to 20'],
    minlength: [3, 'must be greater than 3'],
  },
  // email validation
  email: {
    type: String,
    required: [true, 'Please provide your email'],
    unique: true,
    trim: true,
    lowercase: true,
    validate: [validator.isEmail, 'Please provide a valid email'],
  },
  photo: String,
  // password validation
  password: {
    type: String,
    required: [true, 'Please provide a password'],
    minlength: 8,
    select: false,
  },

  // password confirmation validation
  passwordConfirm: {
    type: String,
    // required: [true, 'Please confirm your password'],
    validate: {
      // This only works on CREATE and SAVE!!!
      validator: function (el) {
        return el === this.password;
      },
      message: 'Passwords are not the same!',
    },
  },
  
  notify:[{
    type: mongoose.Schema.ObjectId,
    ref: 'Notify',
  }],

  activationLink: {
    type: String,
  },
  
  passwordResetToken: String,
  passwordResetExpires: Date,
  activated: {
    type: Boolean,
    default: false,
  },
  
});

userSchema.pre(/^find/, function (next) {
  this.populate({
    path:'notify',
    select:'user message status createdAt '
  })
  next();

});


// Encrpt the password ad Presave it
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    //  only run if password is modified
    return next();
  }
  this.password = await bcrypt.hash(this.password, 12); // hashing password
  this.passwordConfirm = undefined; // delete passwordConfirm field
  next();
});

// Add User Photo
userSchema.pre('save', async function (next) {
  if (this.photo) {
    return next();
  }
  this.photo = `https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=${
    this.name
    .toString()
    .split(' ')
    .join('%20')
  }`;
  next();
});

userSchema.methods.createAccountActivationLink = function () {
  const activationToken = crypto.randomBytes(32).toString('hex');
  this.activationLink = crypto
    .createHash('sha256')
    .update(activationToken)
    .digest('hex');
  return activationToken;
};

// comparing password
userSchema.methods.correctPassword = async function (
  candidate_Password,
  user_Password
) {
  console.log(candidate_Password);
  return await bcrypt.compare(candidate_Password, user_Password);
};

userSchema.methods.createPasswordResetToken = function () {
  const resetToken = crypto.randomBytes(32).toString('hex');

  console.log(resetToken);

  this.passwordResetToken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex');

  this.passwordResetExpires = Date.now() + 10 * 60 * 1000;
  return resetToken;
};

const User = mongoose.model('User', userSchema);
module.exports = User;
