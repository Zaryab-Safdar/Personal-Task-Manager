const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true,
  },
  name: {
    type: String,
    required: [true, 'Please enter task name'],
    trim: true,
  },
  category: {
    type: mongoose.Schema.ObjectId,
    ref: 'Category',
    required: true,
  },
  description: {
    type: String,
    trim: true,
  },
  dueDate: {
    type: Date,
  },
  status: {
    type: String,
    enum: ['inProgress', 'unFinished', 'done'],
    default: 'inProgress',
  },
  expenses: {
    type: Number,
  },
  salary: {
    type: Number,
  },
  pricePerHour:{
    type:Number
  },
  dailyHours:{
    type:Number
  },
  limit:{
    type:Number
  },
  schedule:[
    {
      type:Date,
    }
  ],

  // currency:{
    // type:String
  // }

  createdAt: {
    type: Date,
    default: Date.now,
  },

});


taskSchema.pre(/^find/, function (next) {
  this.populate({
    path: 'category',
    select: 'name _id',
  });
  next();
});

taskSchema.pre(/save|create/,function (next) {

    // const currentData=new Date()
    // let  schedule =this.schedule.map(el => new Date(el)) 
    // let schedule

    this.salary=(this.pricePerHour*this.dailyHours)*this.schedule.length
    next()
    
});


const Task = mongoose.model('Task', taskSchema);
module.exports = Task;
