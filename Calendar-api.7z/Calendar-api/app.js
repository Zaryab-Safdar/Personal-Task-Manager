const express = require('express');
const app = express();
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');  
const helmet = require('helmet');
const mongoSanitize = require('express-mongo-sanitize');
const xss = require('xss-clean');
const path = require('path');
const hpp = require('hpp');

const userRouter = require('./routers/userRouter');
const authRouter = require('./routers/authRouter');
const categoryRouter = require('./routers/categoryRouter');
const taskRouter = require('./routers/taskRouter');

const Task=require('./models/Task')
const User=require('./models/User')
const Notify=require('./models/Notify')

const sendMail = require('./utils/email');
    
const globalErrorHandler = require('./middlewares/globalErrorHandler');

const AppError = require('./utils/appError');
const catchAsync = require('./utils/catchAsync');

// view engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.use(express.json());

console.log(process.env.NODE_ENV);

// set security http headers
app.use(helmet());

if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// $ CORS
app.use(cors());

//  set limit request from same API in timePeroid from same ip
const limiter = rateLimit({
  max: 100, //   max number of limits
  windowMs: 60 * 60 * 1000, // hour
  message:
    ' Too many req from this IP , please Try  again in an Hour ! ',
});

app.use('/api', limiter);

//  Body Parser  => reading data from body into req.body protect from scraping etc
app.use(express.json({ limit: '10kb' }));

// Data sanitization against NoSql query injection
app.use(mongoSanitize()); //   filter out the dollar signs protect from  query injection attact

// Data sanitization against XSS
app.use(xss()); //    protect from molision code coming from html

// testing middleware
app.use((req, res, next) => {
  console.log('this is a middleware');
  next();
});

//*  notify-user before 15-days 7-days and 24-hours 
// TODO: Screenshot 
const notifytask = task => {

  const currentDate=new Date()

  // Notify before 15 days
  let before15Days=new Date(task.dueDate)
  before15Days.setHours(before15Days.getHours()-24*15)

  if(currentDate.getFullYear() === before15Days.getFullYear() &&
  currentDate.getMonth() === before15Days.getMonth() && 
  currentDate.getDate()===before15Days.getDate() &&
  currentDate.getHours()===before15Days.getHours() &&
  currentDate.getMinutes()===before15Days.getMinutes()
  )
  {

    console.log('  Notify before 15-days ')

    // * Send Mail About that Task
    // console.log('Sending Mail To Task',task)

    catchAsync(async()=>{
      
      const notify=await Notify.create({
        message:` Task ${task.name} have only 24-hours remaining `,
        user:task.user._id
      })
      if (!notify) {
        return new AppError('there is some issue in creating notify a task', 500)
      }

      try {
        const user=await User.findById(task.user._id);
        user.notify.unshift(notify.id)
  
        user.save()
        
        // console.log(`user`, user)
        // console.log(`user`, user.name)
        // console.log(`task._id `, task._id )
  
        
      } catch (error) {
          console.log(`error`, error)
      }
    
    
    })()

    // console.log('NOTIFY TASK ADDED TO USER ')
    
    const message = `Hi you have  ${task.name}  task remaning .`;

    let user=task.user.name
    
    sendMail({
      email: task.user.email,
      message,
      subject: ` Notification from task-app `,
      user,
      template: 'simpleEmail.ejs',

    });
  
  }

  // before 7 days
  let before7Days=new Date(task.dueDate)
  before7Days.setHours(before7Days.getHours()-24*7)
  
  if(currentDate.getFullYear() === before7Days.getFullYear() &&
  currentDate.getMonth() === before7Days.getMonth() && 
  currentDate.getDate()===before7Days.getDate() &&
  currentDate.getHours()===before7Days.getHours() &&
  currentDate.getMinutes()===before7Days.getMinutes()
  )
  {

    console.log('  Notify before 7-days ')

    // * Send Mail About that Task
    // console.log('Sending Mail To Task',task)

    catchAsync(async()=>{
      
      const notify=await Notify.create({
        message:` Task ${task.name} have only 24-hours remaining `,
        user:task.user._id
      })
      if (!notify) {
        return new AppError('there is some issue in creating notify a task', 500)
      }

      try {
        const user=await User.findById(task.user._id);
        user.notify.unshift(notify.id)
  
        user.save()
        
        // console.log(`user`, user)
        // console.log(`user`, user.name)
        // console.log(`task._id `, task._id )
  
        
      } catch (error) {
          console.log(`error`, error)
      }
    
    
    })()

    // console.log('NOTIFY TASK ADDED TO USER ')
    
    const message = `Hi you have  ${task.name}  task remaning .`;

    let user=task.user.name
    
    sendMail({
      email: task.user.email,
      message,
      subject: ` Notification from task-app `,
      user,
      template: 'simpleEmail.ejs',

    });


  }

  // send notify before 24 hours

  let prevDate=new Date(task.dueDate)
  prevDate.setHours(prevDate.getHours()-24) 
  
  if(currentDate.getFullYear() === prevDate.getFullYear() &&
  currentDate.getMonth() === prevDate.getMonth() && 
  currentDate.getDate()===prevDate.getDate() &&
  currentDate.getHours()===prevDate.getHours() &&
  currentDate.getMinutes()===prevDate.getMinutes()
  )
  {
    // * Send Mail About that Task
    // console.log('Sending Mail To Task',task)

    catchAsync(async()=>{
      
      const notify=await Notify.create({
        message:` Task ${task.name} have only 24-hours remaining `,
        user:task.user._id
      })
      if (!notify) {
        return new AppError('there is some issue in creating notify a task', 500)
      }

      try {
        const user=await User.findById(task.user._id);
        user.notify.unshift(notify.id)
  
        user.save()
        
        console.log(`user`, user)
        console.log(`user`, user.name)
        console.log(`task._id `, task._id )
  
        
      } catch (error) {
          console.log(`error`, error)
      }
    
    
    })()

    console.log('NOTIFY TASK ADDED TO USER ')
    
    const message = `Hi you have  ${task.name}  task remaning .`;

    let user=task.user.name
    
    sendMail({
      email: task.user.email,
      message,
      subject: ` Notification from task-app `,
      user,
      template: 'simpleEmail.ejs',

    });

  }

}
// TODO: End of Screenshot

// setting notification before 15-7 days and 24 hours to only those tasks which are inProgress

setInterval(() => {

  // iife
  (async()=>{
    
    const tasks=await Task.find({status:'inProgress'}).populate({
      path:'user',
      select:'name email notify'
      })

    // function callback
    
    tasks.forEach(task => {
      notifytask(task)
    })

    // console.log(`task`, tasks)
    console.log(`task`, tasks.length)
  
  })()

  console.log('time')

},1000*60);  // check after minute


// changing the status to unFinished 
const changeStatus=task=>{
  const currentDate=new Date()
  const {dueDate}=task


  if(dueDate < currentDate){
    task.status='unFinished'
    task.save()
  }

}


// check status of task in every 1 hour if date passed then change
// the status from inProgress to infinished
setInterval(()=>{

  (async()=>{
    const tasks=await Task.find({status:'inProgress'})

    const Tasks=tasks.filter( task => task.category.name !== 'job')

    // check the dueDate is passed or Not if passed then change status
    Tasks.forEach(task =>{
      changeStatus(task)
    })
    console.log(`inProgress tasks without job-Cat`, Tasks.length)
  })()

},1000*60)  // check after minute


// changing the status from inProgress => done of salary tasks only 

const changeStatustoDone=task=>{

  const currentDate=new Date()
  let {dueDate}=task
  dueDate=new Date(dueDate)

  if(currentDate.getFullYear() === dueDate.getFullYear() &&
  currentDate.getMonth() === dueDate.getMonth() && 
  currentDate.getDate()===dueDate.getDate() &&
  currentDate.getHours()===dueDate.getHours() &&
  currentDate.getMinutes()===dueDate.getMinutes()
  ){

    task.status='done'
    task.save()

    //* sendNotify to done tasks

    //* Send Mail About that Task
    // console.log('Sending Mail To Task',task)

    catchAsync(async()=>{
      
      const notify=await Notify.create({
        message:` Task ${task.name} has been completed `,
        user:task.user._id
      })
      if (!notify) {
        return new AppError('there is some issue in creating notify a task', 500)
      }

      try {
        const user=await User.findById(task.user._id);
        user.notify.unshift(notify.id)
  
        user.save()
        
        // console.log(`user`, user)
        // console.log(`user`, user.name)
        // console.log(`task._id `, task._id )
  
        
      } catch (error) {
          console.log(`error`, error)
      }

    })()

  }
}

// Automate the salary task if task.dueDate === currentdate change status = done

setInterval(()=>{

  (async()=>{
    const tasks=await Task.find({status:'inProgress'})
    
    const jobTasks=tasks.filter( task => task.category.name === 'job')

    jobTasks.forEach(task =>{
      changeStatustoDone(task)
    })
    
    console.log(` jobtasks  `, jobTasks.length)

  })()

},1000*60)  // 1 minutes

//* notifyStats to User in 7th-day , 14th-day , 21-day and last day of current-month

const notifyStats = el => {

  const currentDate=new Date();

  // console.log(`currentDate`, currentDate.getDate())

  var date = new Date();
  //* first and last Dates of current Month
  var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);      // used for find the dates of curent month
  var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);   // used for notify at the end of the month

  // console.log(`firstDay`, firstDay.getDate())
  // console.log(`lastDay`, lastDay.getDate())

  //* notify-Stats in the 7th day of the current month
  let seventhDay=new Date(firstDay)
  seventhDay.setHours(seventhDay.getHours()+24*6)
  // console.log(`seventhDay`,seventhDay.getDate())

  if(currentDate.getFullYear() === seventhDay.getFullYear() &&
  currentDate.getMonth() === seventhDay.getMonth() && 
  currentDate.getDate()===seventhDay.getDate()
  )
  {

    catchAsync(async()=>{
       
      const tasks=await Task.find({user:el._id,status:'done','dueDate':{$gte:firstDay,$lte:seventhDay}})
      console.log(`Total tasksss`, tasks.length)
      
      const jobTasks=tasks.filter( task => task.category.name === 'job')
      const expenseTasks=tasks.filter( task => task.category.name === 'expense')

      // console.log(`jobTasks`, jobTasks)
      // console.log(`expenseTasks`, expenseTasks)

      console.log(`jobTasks`, jobTasks.length)
      console.log(`expenseTasks`, expenseTasks.length)

      let totalSalary=0;
      jobTasks.forEach(task => totalSalary+=task.salary)
      console.log(`totalSalary`, totalSalary)

      let totalExpenses=0;
      expenseTasks.forEach(task => totalExpenses+=task.expenses)
      console.log(`totalExpenses`, totalExpenses)

      const savings=totalSalary-totalExpenses
      console.log(`Savings `, savings )
      

      const notify=await Notify.create({
        message:` Stats totalSalary -> ${totalSalary} TotalExpense -> ${totalExpenses} savings -> ${savings}`,
        user:el._id
      })
      if (!notify) {
        return new AppError('there is some issue in creating notify a task', 500)
      }

      console.log(`notify`, notify)


     try {
        const user=await User.findById(el._id);
      user.notify.unshift(notify.id)

      user.save()
      
      // console.log(`user`, user)
      // console.log(`user`, user.name)
      // console.log(`task._id `, task._id )
     } catch (error) {
        console.log(`error`, error)
     }

    })()
  }

  
  //* notify-Stats in the 14th day of the current month
  let forteenthDay=new Date(firstDay)
  forteenthDay.setHours(forteenthDay.getHours()+24*13)
  // console.log(`forteenthDay`, forteenthDay.getDate())
    
  if(currentDate.getFullYear() === forteenthDay.getFullYear() &&
  currentDate.getMonth() === forteenthDay.getMonth() && 
  currentDate.getDate()===forteenthDay.getDate()
  )
  {

    catchAsync(async()=>{
       
      const tasks=await Task.find({user:el._id,status:'done','dueDate':{$gte:seventhDay,$lte:forteenthDay}})
      console.log(`Total tasksss`, tasks.length)
      
      const jobTasks=tasks.filter( task => task.category.name === 'job')
      const expenseTasks=tasks.filter( task => task.category.name === 'expense')

      // console.log(`jobTasks`, jobTasks)
      // console.log(`expenseTasks`, expenseTasks)

      console.log(`jobTasks`, jobTasks.length)
      console.log(`expenseTasks`, expenseTasks.length)

      let totalSalary=0;
      jobTasks.forEach(task => totalSalary+=task.salary)
      console.log(`totalSalary`, totalSalary)

      let totalExpenses=0;
      expenseTasks.forEach(task => totalExpenses+=task.expenses)
      console.log(`totalExpenses`, totalExpenses)

      const savings=totalSalary-totalExpenses
      console.log(`Savings `, savings )
      

      const notify=await Notify.create({
        message:` Stats totalSalary -> ${totalSalary} TotalExpense -> ${totalExpenses} savings -> ${savings}`,
        user:el._id
      })
      if (!notify) {
        return new AppError('there is some issue in creating notify a task', 500)
      }

      console.log(`notify`, notify)


     try {
        const user=await User.findById(el._id);
      user.notify.unshift(notify.id)

      user.save()
      
      // console.log(`user`, user)
      // console.log(`user`, user.name)
      // console.log(`task._id `, task._id )
     } catch (error) {
        console.log(`error`, error)
     }

    })()
  }
  //* notify-Stats in the 21th day of the current month
  let twenty1thDay=new Date(firstDay)
  twenty1thDay.setHours(twenty1thDay.getHours()+24*20)
  // console.log(`twenty1thday`, twenty1thDay.getDate())

  if(currentDate.getFullYear() === twenty1thDay.getFullYear() &&
  currentDate.getMonth() === twenty1thDay.getMonth() && 
  currentDate.getDate()===twenty1thDay.getDate()
  )
  {

    catchAsync(async()=>{
       
      const tasks=await Task.find({user:el._id,status:'done','dueDate':{$gte:forteenthDay,$lte:twenty1thDay}})
      console.log(`Total tasksss`, tasks.length)
      
      const jobTasks=tasks.filter( task => task.category.name === 'job')
      const expenseTasks=tasks.filter( task => task.category.name === 'expense')

      // console.log(`jobTasks`, jobTasks)
      // console.log(`expenseTasks`, expenseTasks)

      console.log(`jobTasks`, jobTasks.length)
      console.log(`expenseTasks`, expenseTasks.length)

      let totalSalary=0;
      jobTasks.forEach(task => totalSalary+=task.salary)
      console.log(`totalSalary`, totalSalary)

      let totalExpenses=0;
      expenseTasks.forEach(task => totalExpenses+=task.expenses)
      console.log(`totalExpenses`, totalExpenses)

      const savings=totalSalary-totalExpenses
      console.log(`Savings `, savings )
      

      const notify=await Notify.create({
        message:` Stats totalSalary -> ${totalSalary} TotalExpense -> ${totalExpenses} savings -> ${savings}`,
        user:el._id
      })
      if (!notify) {
        return new AppError('there is some issue in creating notify a task', 500)
      }

      console.log(`notify`, notify)


     try {
        const user=await User.findById(el._id);
      user.notify.unshift(notify.id)

      user.save()
      
      // console.log(`user`, user)
      // console.log(`user`, user.name)
      // console.log(`task._id `, task._id )
     } catch (error) {
        console.log(`error`, error)
     }

    })()
  }
  
  //* notify-Stats in the 21th day of the current month
  var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);      // used for find the dates of curent month
  var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);   // used for notify at the end of the month
  
  if(currentDate.getFullYear() === lastDay.getFullYear() &&
  currentDate.getMonth() === lastDay.getMonth() && 
  currentDate.getDate()===lastDay.getDate()
  )
  {

    catchAsync(async()=>{
       
      const tasks=await Task.find({user:el._id,status:'done','dueDate':{$gte:firstDay,$lte:lastDay}})
      console.log(`Total tasksss`, tasks.length)  
      
      const jobTasks=tasks.filter( task => task.category.name === 'job')
      const expenseTasks=tasks.filter( task => task.category.name === 'expense')

      // console.log(`jobTasks`, jobTasks)
      // console.log(`expenseTasks`, expenseTasks)

      console.log(`jobTasks`, jobTasks.length)
      console.log(`expenseTasks`, expenseTasks.length)

      let totalSalary=0;
      jobTasks.forEach(task => totalSalary+=task.salary)
      console.log(`totalSalary`, totalSalary)

      let totalExpenses=0;
      expenseTasks.forEach(task => totalExpenses+=task.expenses)
      console.log(`totalExpenses`, totalExpenses)

      const savings=totalSalary-totalExpenses
      console.log(`Savings `, savings )
      

      const notify=await Notify.create({
        message:` Stats totalSalary -> ${totalSalary} TotalExpense -> ${totalExpenses} savings -> ${savings}`,
        user:el._id
      })
      if (!notify) {
        return new AppError('there is some issue in creating notify a task', 500)
      }

      console.log(`notify`, notify)


     try {
        const user=await User.findById(el._id);
      user.notify.unshift(notify.id)

      user.save()
      
      // console.log(`user`, user)
      // console.log(`user`, user.name)
      // console.log(`task._id `, task._id )
     } catch (error) {
        console.log(`error`, error)
     }

    })()
  }


}

// check status of task in every 24 hours and send weekly-monthly notify of stats
// send notify in 7,14,21,28, 30th of the month

setInterval(()=>{
  (async()=>{
    
    const users=await User.find()

    users.forEach(el =>{
      notifyStats(el)
    })

    // console.log(`done tasks`, tasks)
    console.log(`USERS`, users.length)

  })()

},1000*60*60*24)      // check after every 24 hour


// routes

app.use('/api/auth', authRouter);
app.use('/api/users', userRouter);
app.use('/api/category', categoryRouter);
app.use('/api/task', taskRouter);

// handling all (get,post,update,delete.....) unhandled routes

app.all('*', (req, res, next) => {
  next(
    new AppError(`Can't find ${req.originalUrl} on the server`, 404)
  );
});

// error handling middleware
app.use(globalErrorHandler);
module.exports = app;


// Date format used in App
// "dueDate":"Sat jun 12 2021 19:44:00 GMT+0500 (Pakistan Standard Time)"
