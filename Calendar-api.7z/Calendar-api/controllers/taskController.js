const User = require('../models/User');
const Task = require('../models/Task');
const Category = require('../models/Category');
const catchAsync = require('./../utils/catchAsync');
const AppError = require('./../utils/appError');

// create Task

exports.createTask = catchAsync(async (req, res, next) => {
  /*
  shecdule is always b/w todays-date and dueDate and checked from frontend also
  schedule = schedule.map(el => new Date(el)) 
  */

  const {
    name,
    description,
    category,
    dailyHours,
    pricePerHour,
    limit,
    expenses,
    dueDate,
    status,
  } = req.body;

  const duedate = new Date(dueDate);
  const currentDate = new Date();

  console.log(`dueDate`, duedate);
  console.log(`dueDate-year`, duedate.getFullYear());
  console.log(`dueDate-month`, duedate.getMonth());
  console.log(`dueDate-day`, duedate.getDate());
  console.log(`dueDate-hour`, duedate.getHours());
  console.log(`dueDate-minute`, duedate.getMinutes());

  console.log(`currentDate`, currentDate);
  console.log(`currentDate-year`, currentDate.getFullYear());
  console.log(`currentDate-month`, currentDate.getMonth());
  console.log(`currentDate-day`, currentDate.getDate());
  console.log(`currentDate-hour`, currentDate.getHours());
  console.log(`currentDate-minute`, currentDate.getMinutes());

  // check created-Date is not in the Past
  // if(currentDate.getFullYear() < duedate.getFullYear() &&
  // currentDate.getMonth() < duedate.getMonth() &&
  // currentDate.getDate() < duedate.getDate() &&
  // currentDate.getHours() < duedate.getHours() &&
  // currentDate.getMinutes() < duedate.getMinutes()
  // )
  if (duedate <= currentDate) {
    return next(new AppError(` cannot update task in past `, 400));
  }
  const { schedule } = req.body;
  // console.log(`schedule`, schedule)
  // console.log(`schedule`, schedule.length)
  // var last = schedule[schedule.length - 1];
  // console.log('last :>> ', last);
  // find the working days and calculte total hours

  if (schedule) {
    const totalHours = schedule.length * dailyHours;
    // checking limit and also cheked in frontend

    if (limit && limit > 0 && limit < totalHours) {
      return next(
        new AppError(` Your Hours are exceeding your limit`, 400)
      );
    }
  }

  // finding category
  const category_ID = req.body.category;
  const checkCategory = await Category.findById(category_ID);

  // console.log('category :>> ', checkCategory);
  // console.log('category_name :>> ', checkCategory.name);

  let createTask = req.body;

  if (checkCategory.name === 'job') {
    createTask = await Task.create({
      user: req.user._id,
      name: name,
      category: category,
      description: description,
      dueDate: dueDate,
      dailyHours: dailyHours,
      pricePerHour: pricePerHour,
      limit: limit,
      schedule: schedule,
      status,
    });
  } else if (checkCategory.name === 'expense') {
    createTask = await Task.create({
      user: req.user._id,
      name: name,
      category: category,
      description: description,
      dueDate: dueDate,
      expenses: expenses,
      status,
    });
  } else {
    createTask = await Task.create({
      user: req.user._id,
      name: name,
      category: category,
      description: description,
      dueDate: dueDate,
      status,
    });
  }

  if (!createTask) {
    return next(
      new AppError('there is some issue in creating a task', 500)
    );
  }

  const createdTask = await Task.findById(createTask._id)
    .populate('category')
    .exec();

  console.log('createdTask :>> ', createdTask);

  res.status(200).json({
    status: 'success',
    task: createdTask,
  });
});

// Duplicate task by Id

exports.duplicateTask = catchAsync(async (req, res, next) => {
  const task = await Task.findById(req.params.id);

  // console.log(`task`, task);
  // console.log(`categoryID`, task.category._id);

  if (!task) {
    return next(new AppError('there is no task found', 404));
  }

  const category = task.category._id;
  const {
    status,
    user,
    name,
    description,
    dueDate,
    dailyHours,
    pricePerHour,
    limit,
    schedule,
    createdAt,
    salary,
    expenses,
  } = task;

  const date = new Date(dueDate);
  const currentDate = new Date();

  // console.log(`dueDate`, dueDate);
  // console.log(`date`, date);

  //  duplicate only present tasks

  if (date < currentDate) {
    return next(new AppError(` cannot create task in past `, 400));
  }

  let duplicateTask;

  if (task.category.name === 'job') {
    duplicateTask = await Task.create({
      status: status,
      user: user,
      category: category,
      name: name,
      description: description,
      dueDate: dueDate,
      dailyHours: dailyHours,
      pricePerHour: pricePerHour,
      limit: limit,
      salary: salary,
      schedule: schedule,
      createdAt: createdAt,
    });
  } else if (task.category.name === 'expense') {
    duplicateTask = await Task.create({
      status: status,
      user: user,
      category: category,
      name: name,
      description: description,
      dueDate: dueDate,
      expenses: expenses,
      createdAt: createdAt,
    });
  } else {
    duplicateTask = await Task.create({
      status: status,
      user: user,
      category: category,
      name: name,
      description: description,
      dueDate: dueDate,
      createdAt: createdAt,
    });
  }

  if (!duplicateTask) {
    return next(
      new AppError('there is some issue in duplicatiing a task', 500)
    );
  }

  duplicateTask = await Task.findById(duplicateTask._id)
    .populate('category')
    .exec();

  console.log('duplicatedTask :>> ', duplicateTask);

  res.status(200).json({
    status: 'success',
    duplicateTask,
  });
});

// get Singel-Task

exports.getTask = catchAsync(async (req, res, next) => {
  const task = await Task.findById(req.params.id);

  // const{dueDate}=task
  // const duedate=new Date(dueDate)
  // console.log(`duedate.getMonth()`, duedate.getMonth())
  // console.log(`duedate.getDate()`, duedate.getDate())

  if (!task) {
    return next(
      new AppError(
        `No task found against this id ${req.params.id}`,
        404
      )
    );
  }
  res.status(200).json({
    status: 'success',
    task,
  });
});

// get task of login-User

exports.getMyTasks = catchAsync(async (req, res, next) => {
  const tasks = await Task.find({
    user: req.user._id,
  });

  if (!tasks) tasks = [];

  console.log(`tasks`, tasks.length);

  res.status(200).json({
    status: 'success',
    length: tasks.length,
    tasks,
  });
});

//  get all tasks for testing

exports.getTasks = catchAsync(async (req, res, next) => {
  let query = Task.find();
  if (req.query.status)
    query = query.find({ status: req.query.status });

  const tasks = await query;

  if (!tasks) tasks = [];

  // console.log(`tasks`, tasks);

  res.status(200).json({
    status: 'success',
    length: tasks.length,
    tasks,
  });
});

//  complete the task and change the status from inProgress => Done

exports.completeTask = catchAsync(async (req, res, next) => {
  const task = await Task.findById(req.params.id);

  if (!task) {
    return next(
      new AppError(
        `No task found against this id ${req.params.id}`,
        404
      )
    );
  }

  task.status = 'done';
  await task.save();

  res.status(200).json({
    status: 'success',
    task,
  });
});

// repeat the task and update the dates from now On

exports.repeatTask = catchAsync(async (req, res, next) => {
  const task = await Task.findById(req.params.id);

  console.log(`task`, task)

  if (!task)
    return next(new AppError(`Error in repeating Task`, 500));

  const { createdAt, dueDate } = task;

  console.log(`createdAt`, createdAt.getDate())
  console.log(`before-dueDate`, dueDate.getDate())
  // find the difference b/w createdAt and dueDate and the create new task
  //on the base of 'differce from currentDate

  var Difference_In_Time = dueDate.getTime() - createdAt.getTime();
  var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);

  // console.log(`difference`, Difference_In_Days);

  // setting createdAt to currentDate
  const currentDate = new Date();
  task.createdAt = currentDate;



  // creating new dueDate on the Base of difference
  let updateddueDate = new Date(currentDate);
  updateddueDate.setHours(updateddueDate.getHours() + 24 * Difference_In_Days);

  // console.log(`updateddueDate`, updateddueDate.getDate());

  task.dueDate = updateddueDate;

  console.log('updated-createdat', task.createdAt.getDate());
  console.log('updated-dueDate', task.dueDate.getDate());

  task.status = 'inProgress';

  await task.save();

  res.status(200).json({
    status: 'success',
    task,
  });
});

// get stats b/w specific Dates

exports.Stats = catchAsync(async (req, res, next) => {
  // console.log(`req.query`, req.query)
  // const {sdate,edate}=req.query

  const { sdate, edate } = req.body;

  // const currentDate=new Date()
  const start_Date = new Date(sdate);
  const end_Date = new Date(edate);

  // console.log(`start_Date =`, start_Date)
  // console.log(`sYear =`, start_Date.getFullYear())
  // console.log(`sMonth =`, start_Date.getMonth())
  // console.log(`sDate =`, start_Date.getDate())

  // console.log(`end_date =`, end_Date)
  // console.log(`eYear =`, end_Date.getFullYear())
  // console.log(`eMonth =`, end_Date.getMonth())
  // console.log(`end_date =`, end_Date.getDate())

  const tasks = await Task.find({
    user: req.user._id,
    status: 'done',
    dueDate: { $gte: start_Date, $lte: end_Date },
  });

  // const tasks=await Task.find({user:req.user._id})
  const jobTasks = tasks.filter(
    (task) => task.category.name === 'job'
  );
  const expenseTasks = tasks.filter(
    (task) => task.category.name === 'expense'
  );

  // console.log(`jobTasks`, jobTasks)
  console.log(`expenseTasks`, expenseTasks);
  console.log(`jobTasks`, jobTasks.length);
  console.log(`expenseTasks`, expenseTasks.length);

  // totalSalary
  let totalSalary = 0;
  jobTasks.forEach((task) => (totalSalary += task.salary));
  console.log(`totalSalary`, totalSalary);

  // totalExpenses
  let totalExpenses = 0;
  expenseTasks.forEach((task) => (totalExpenses += task.expenses));

  console.log(`totalExpenses`, totalExpenses);

  // Savings
  let savings = 0;
  savings = totalSalary - totalExpenses;
  console.log(`Savings `, savings);

  res.status(200).json({
    status: 'success',
    length: tasks.length,
    totalSalary: totalSalary,
    totalExpenses: totalExpenses,
    savings: savings,
    tasks,
  });
});

// get Stats for testing only

exports.getweeklyStats = catchAsync(async (req, res, next) => {
  const currentDate = new Date();

  console.log(`currentDate`, currentDate.getDate());

  var date = new Date();
  var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

  console.log(`firstDay`, firstDay.getDate());

  let seventhDay = new Date(firstDay);
  seventhDay.setHours(seventhDay.getHours() + 24 * 6);
  console.log(`seventhDay`, seventhDay.getDate());

  let forteenthDay = new Date(firstDay);
  forteenthDay.setHours(forteenthDay.getHours() + 24 * 16);
  console.log(`forteenthDay`, forteenthDay.getDate());

  let twenty1thDay = new Date(firstDay);
  twenty1thDay.setHours(twenty1thDay.getHours() + 24 * 25);
  console.log(`twenty1thday`, twenty1thDay.getDate());

  // check logic

  let tasks;
  let users;
  let totalSalary = 0;
  let totalExpenses = 0;
  let savings = 0;

  if (
    currentDate.getFullYear() === forteenthDay.getFullYear() &&
    currentDate.getMonth() === forteenthDay.getMonth() &&
    currentDate.getDate() === forteenthDay.getDate()
  ) {
    users = await User.find();
    users.forEach(async (el) => {
      tasks = await Task.find({
        user: el._id,
        status: 'done',
        dueDate: { $gte: firstDay, $lte: twenty1thDay },
      });

      console.log(` USER `, el._id);
      console.log(`tasks =>`, tasks.length);
      // console.log(`tasks`, tasks)

      const jobTasks = tasks.filter(
        (task) => task.category.name === 'job'
      );
      const expenseTasks = tasks.filter(
        (task) => task.category.name === 'expense'
      );

      // console.log(`jobTasks`, jobTasks)
      // console.log(`expenseTasks`, expenseTasks)

      console.log(`jobTasks`, jobTasks.length);
      console.log(`expenseTasks`, expenseTasks.length);

      jobTasks.forEach((task) => (totalSalary += task.salary));
      console.log(`totalSalary`, totalSalary);

      expenseTasks.forEach(
        (task) => (totalExpenses += task.expenses)
      );
      console.log(`totalExpenses`, totalExpenses);

      savings = totalSalary - totalExpenses;
      console.log(`Savings `, savings);
    });
  }

  res.status(200).json({
    status: 'success',
    // length:tasks.length,
    // totalSalary:totalSalary,
    // totalExpenses:totalExpenses,
    // savings:savings,
    // tasks
  });
});

// update task

exports.updateTask = catchAsync(async (req, res, next) => {
  const { dueDate, limit, dailyHours, schedule } = req.body;

  const date = new Date(dueDate);
  const currentDate = new Date();

  // console.log(`dueDate`, dueDate);
  // console.log(`date`, date);

  // task cannot be in  past
  if (date < currentDate) {
    return next(new AppError(` cannot update task in past `, 400));
  }

  const totalHours = schedule.length * dailyHours;
  // checking limit and also cheked in frontend
  if (limit > 0 && limit < totalHours) {
    return next(
      new AppError(` Your Hours are exceeding your limit `, 400)
    );
  }

  // if task update the task status will be inProgress

  const task = await Task.findById(req.params.id);
  if (!task) return next(new AppError(`Task not found `, 404));

  task.status = 'inProgress';
  await task.save();

  const updateTask = await Task.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
      new: true,
      runValidators: true,
    }
  );

  if (!updateTask)
    return next(new AppError(`Error updating Task`, 404));

  res.status(200).json({
    status: 'success',
    updateTask,
  });
});

// delete task

exports.deleteTask = catchAsync(async (req, res, next) => {
  const deletedTask = await Task.findByIdAndDelete(req.params.id);

  if (!deletedTask)
    return next(
      new AppError(`No task found against id ${req.params.id}`, 404)
    );

  res.status(200).json({
    status: 'success',
    task: deletedTask,
  });
});
