const User = require('../models/User');
const Task = require('../models/Task');
const Notify = require('../models/Notify');
const catchAsync = require('./../utils/catchAsync');
const AppError = require('./../utils/appError');

exports.getUser = catchAsync(async (req, res, next) => {
   const user = await User.findById(req.user._id).populate({
      path:'notify',
      select:'user message status createdAt '
   })


   if (!user)
      return next(new AppError( `No User found against id ${req.params.id}`,404));

   res.status(200).json({
      status: 'success',
      user,
   });
   

});

// for testing 

exports.getUsers=catchAsync(async(req,res,next)=>{
   const users=await User.find()

   if(!users)
      return next(new AppError(' No user created yet',404))
   
   res.status(200).json({
      status:'success',
      length:users.length,
      users,
   })
})

// delete user for testing purposes

exports.deleteUser = catchAsync(async (req, res, next) => {
   const deleteUser= await User.findByIdAndDelete(req.params.id);  

   if (!deleteUser)
       return next(new AppError(`No user found against id ${req.params.id}`,404));

   res.status(200).json({
     status: 'success',
     user: deleteUser,
     tasks
   });

});


// get all Nofites for testing purpose

exports.getNotify=catchAsync(async(req,res,nex)=>{
  
   const notify=await Notify.find()
   if(!notify)
      return next(new AppError(' No user created yet',404))
   
   res.status(200).json({
      status:'success',
      length:notify.length,
      notify,
   })
})

// update Notify to seen

exports.checkNotify=catchAsync(async(req,res,next)=>{

   const notify=await Notify.updateMany({user:req.user._id},{status:'seen'})

   res.status(200).json({
      status:'success',
      notify,
   })

})