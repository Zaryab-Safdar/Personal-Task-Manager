const Category = require('../models/Category');
const catchAsync = require('./../utils/catchAsync');
const AppError = require('./../utils/appError');

// create category

exports.createCategory = catchAsync(async (req, res, next) => {
  const category = await Category.create({
    user: req.user._id,
    name: req.body.name,
  });
  //   const category = await Category.create(req.body);

  if (!category)
    return next(new AppError(' No category created '), 500);

  res.status(200).json({
    status: 'success',
    category,
  });
});

// get all categories

exports.getCategories = catchAsync(async (req, res, next) => {
  let category = await Category.find({ user: req.user._id });
  //  const category=await Category.find()

  if (!category || category.length === 0) {
    // * Create Three basic Categories
    await Promise.all([
      Category.create({ user: req.user._id, name: 'education' }),
      Category.create({ user: req.user._id, name: 'expense' }),
      Category.create({ user: req.user._id, name: 'job' }),
    ]);
  }

  category = await Category.find({ user: req.user._id });

  res.status(200).json({
    status: 'success',
    length: category.length,
    category,
  });
});

// delete category for testing only

exports.deleteCategory = catchAsync(async (req, res, next) => {
  const deleteCategory = await Category.findByIdAndDelete(
    req.params.id
  );

  if (!deleteCategory)
    return next(
      new AppError(
        `No category found against id ${req.params.id}`,
        404
      )
    );

  res.status(200).json({
    status: 'success',
    category: deleteCategory,
  });
});
