const express = require('express');
const taskController = require('../controllers/taskController');
const protect = require('../middlewares/protect');

const router = express.Router();

router.use(protect); //  protect all router which are comming after this middleware

router
  .route('/')
  .get(taskController.getTasks)
  .post(taskController.createTask);

router
  .route('/myTasks')
  .get(taskController.getMyTasks)

router
  .route('/stats')
  .post(taskController.Stats)

router
  .route('/weeklyStats')
  .get(taskController.getweeklyStats)



router
  .route('/:id')
  .get(taskController.getTask)
  .patch(taskController.updateTask)
  .delete(taskController.deleteTask);

router.route('/:id/duplicate').post(taskController.duplicateTask);

router.route('/:id/complete').patch(taskController.completeTask);

router.route('/:id/repeat').patch(taskController.repeatTask);


module.exports = router;
