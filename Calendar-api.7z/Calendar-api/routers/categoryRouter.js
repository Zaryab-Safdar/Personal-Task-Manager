const express = require('express');
const categoryController = require('../controllers/categoryController');
const protect = require('../middlewares/protect');

const router = express.Router();

router.use(protect); //  protect all router which are comming after this middleware

router
   .route('/')
   .get(categoryController.getCategories)
   .post(categoryController.createCategory)

router
    .route('/:id')
    .delete(categoryController.deleteCategory)

module.exports = router;
